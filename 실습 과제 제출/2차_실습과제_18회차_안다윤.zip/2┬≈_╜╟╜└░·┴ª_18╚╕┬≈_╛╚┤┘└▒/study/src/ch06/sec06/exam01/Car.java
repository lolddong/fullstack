package ch06.sec06.exam01;

public class Car {
    // 필드 선언
    String model;
    // 기본값: null
    boolean start;
    // 기본값: false
    int speed;
    // 기본값: 0
}
