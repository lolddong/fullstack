package ch06.sec07.exam01;

public class Car {
    // 멤버 변수 (필드) 선언
    String model;
    String color;
    int maxSpeed;

    // 생성자 선언
    public Car(String model, String color, int maxSpeed) {
        this.model = model;
        this.color = color;
        this.maxSpeed = maxSpeed;
    }
}
