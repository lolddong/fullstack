package ch15.sec06.exam02;

import lombok.AllArgsConstructor;

@AllArgsConstructor // 전체 매개변수 생성자
public class Message {
    public String command;
    public String to;
}
