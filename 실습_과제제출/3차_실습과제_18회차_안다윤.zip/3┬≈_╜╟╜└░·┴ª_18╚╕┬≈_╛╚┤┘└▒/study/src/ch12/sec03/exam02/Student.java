package ch12.sec03.exam02;

public class Student {
    private int no;
    private String name;
}
